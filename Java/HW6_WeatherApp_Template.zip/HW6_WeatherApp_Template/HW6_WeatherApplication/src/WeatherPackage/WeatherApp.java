package WeatherPackage;

import java.io.File;
import java.io.IOException;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class WeatherApp extends Application {

      // Constants
    private static final int MAX_RECORDS = 7;
    
    // Variables and Instances of Classes
    private WeatherRecord weeklyDataArray[] = new WeatherRecord[MAX_RECORDS];        //store all student records
    private int nextDay = 0;         // location of next empty position in the array
    private int numDays = 0;         // number of input records
  
   
    private String xmlDayName;    // temporary storage for name of weekday from xml
    private String xmlForecast;   //temporary storage for forecast from xml
    private int xmlHighTemp;   //temporary storage for high temperature from xml
    private int xmlLowTemp;    // temporary storage for low temperature from xml
   
     // pane declaration
    private VBox mainPane;
    private HBox buttonPane;
    private WeatherPane weatherPane;
   
    // button declarations
    private Button lionButton;
   
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {

        mainPane = new VBox(10); // main pane which will serve as placeholder for button pane and graphics pane
        
        buttonPane = new HBox(10); // pane to hold GUI components for days, week and statistics
        buttonPane.setPadding(new Insets(15, 15, 15, 15));
        
        weatherPane = new WeatherPane(this); // Create a weather pane and send copy of host for images

        // read XML data from file and store in weeklyDataArray 
        readXMLFile("Weather.xml");

        lionButton = new Button("Lion");
        lionButton.setOnAction(e -> weatherPane.drawGraphics(weeklyDataArray, 0));
        buttonPane.getChildren().add(lionButton);

        mainPane.getChildren().add(buttonPane);
        mainPane.getChildren().add(weatherPane);
        
        // Create a scene and place it in the stage
        Scene scene = new Scene(mainPane, 500, 500);
        primaryStage.setTitle("Weather App"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
    }

         
         
    /**
     * The main method is only needed for the IDE with limited JavaFX support.
     * Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }

    //the method reads info from the input XML file, and then stores it in the studentArray[] 
    public void readXMLFile(String filename) {
        try {
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            builderFactory.setValidating(true);
            DocumentBuilder builder = builderFactory.newDocumentBuilder();
            Document document = builder.parse(new File(filename));
            NodeList list = document.getElementsByTagName("dailyWeather");

            //This for loop gathers all the student attributes, puts them in a WeatherRecord object
            //then stores that student in the weekArray
            for (int i = 0; i < list.getLength(); i++) {
                Element element = (Element) list.item(i);
                 
                xmlDayName = element.getAttribute("name");
                xmlForecast = element.getAttribute("forecast");
                xmlHighTemp = getHighTemp(element);
                xmlLowTemp = getLowTemp(element);
                WeatherRecord myWeather = new WeatherRecord(xmlDayName, xmlForecast, xmlHighTemp, xmlLowTemp);

                // store student record in array
                weeklyDataArray[nextDay] = myWeather;

                // increment number of student records and move to next position in studentArray
                numDays++;
                nextDay++;
                
                System.out.println(myWeather.toString());

            }//end for loop loading the studentArray[] with full student records

        }//end try block
        catch (ParserConfigurationException parserException) {
            parserException.printStackTrace();
        }//end catch block
        catch (SAXException saxException) {
            saxException.printStackTrace();
        }//end catch block
        catch (IOException ioException) {
            ioException.printStackTrace();
        }//end catch block

    }//end readFile()

    //RETURNS THE HIGH TEMP OF DAILY WEATHER
    public int getHighTemp(Element parent) {
        NodeList child = parent.getElementsByTagName("highTemp");
        Node childTextNode = child.item(0).getFirstChild();
        return Integer.parseInt(childTextNode.getNodeValue());
    }

    //RETURNS THE LOW TEMP OF DAILY WEATHER   
    public int getLowTemp(Element parent) {
        NodeList child = parent.getElementsByTagName("lowTemp");
        Node childTextNode = child.item(0).getFirstChild();
        return Integer.parseInt(childTextNode.getNodeValue());
    }


}
