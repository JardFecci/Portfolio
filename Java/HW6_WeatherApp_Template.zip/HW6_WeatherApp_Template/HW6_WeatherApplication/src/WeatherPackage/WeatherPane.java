package WeatherPackage;
import javafx.application.HostServices;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class WeatherPane extends Pane {
    

    
    private WeatherApp myApp;
    
    public WeatherPane(WeatherApp a)
    {
       myApp = a;
    }

    public void drawGraphics(WeatherRecord[] wInfo, int index) {

        getChildren().clear(); // clear the pane for next graphic
        
        // add code to display the input name of the weekday contained in  wInfo parameter
        
        // add code to display the low  temperature contained in  wInfo parameter
        
        // add code to display the high temperature contained in  wInfo parameter
     
                
        switch (wInfo[index].getForecast()) // use forecast from wInfo parameter to draw appropriate graphics
        {    
        
            case "Sun":         // Code to draw the graphics for Sun

                Text text0 = new Text(100, 100, "Drawing the graphic for Sun");
                text0.setFill(Color.GREEN);  // Change the pen color
                getChildren().add(text0);

                // Change the wording of the text above and add code here to display graphics for sunny weather

                // TEMPORARY CODE FOR DRAWING IMAGE OF NITTANY LION.....
                // USED AS AN EXAMPLE AND SHOULD BE REMOVED AFTER ADDING YOUR WEATHER IMAGE
                ImageView nittany = new ImageView(new Image(WeatherPane.class.getResource("/NittanyLion.png").toString()));
                nittany.setX(100);
                nittany.setY(150);
                getChildren().add(nittany);
                
                break;
                
            case "Clouds":   // Code to draw the graphics for Clouds

                Text text1 = new Text(200, 100, "Drawing the graphic for Clouds");
                text1.setFill(Color.RED);  // Change the pen color              
                getChildren().add(text1);
                
                // Change the wording of the text above and add code here to display graphics for cloudy weather

                break;
                
            case "Snow":   // Code to draw the graphics for Snow
                Text text2 = new Text(330, 150, "Drawing the graphic for Snow");
                text2.setFill(Color.BLUE);  // Change the pen color
                getChildren().add(text2);
                
                // Change the wording of the text above and add code here to display graphics for snowy weather

                break;
                
            case "Rain":  // Code to draw the graphics for rain
                Text text3 = new Text(200, 300, "Drawing the graphic for Rain");
                text3.setFill(Color.MAGENTA);  // Change the pen color
                getChildren().add(text3);
                
                // Change the wording of the text above and add code here to display graphics for  rainy weather

                break;
                
            case "Wind":   // Code to draw the graphics for wind
                Text text4 = new Text(250, 50, "Drawing the graphics for Wind");
                text4.setFill(Color.TOMATO);  // Change the pen color
                getChildren().add(text4);
                
                // Change the wording of the text above and add code here to display graphics for windy weather

                break;
                
            default:
        
        } // end switch
     

    }
}
